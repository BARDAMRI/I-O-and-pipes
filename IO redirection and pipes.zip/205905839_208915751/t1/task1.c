#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <linux/limits.h>
#include <sys/wait.h>
#include <unistd.h>




int main(int argc,char**argv){
int j;
int debugMod;
for(j=1; j<argc;j++){
    if(strcmp(argv[j],"-d")==0)
        debugMod=1;
    else
        debugMod=0;    
}

    int pipe_buffer [2];
    pid_t pid1,pid2;
    char* lsCommand[] ={"ls","-l",0}; 
    char* tailCommand[]= {"tail","-n","2",0};
    if (pipe(pipe_buffer)==-1)
    {
        perror("failed to open pipe");
        exit(1);
    }
    if(debugMod)    fprintf(stderr,"(parent_process>forking…) \n");
    pid1=fork();
     if (pid1==-1)
    {
        perror("failed to create child process");
        exit(1);
    }
    if(!pid1){
        close(STDOUT_FILENO);
        if (debugMod)    fprintf(stderr,"(child1>redirecting stdout to the write end of the pipe…)\n");
        if(dup(pipe_buffer[1])==-1){
            perror("failed to duplicate child");
            exit(1);
        }
        close(pipe_buffer[1]);
        if (debugMod)   fprintf(stderr,"(child1>going to execute cmd: …)\n");
        execvp(lsCommand[0],lsCommand);
        exit(1);
    }
    else
    {
        if (debugMod)   fprintf(stderr,"(parent_process>created process with id: %d\n",pid1);
        if(debugMod)    fprintf(stderr,"(parent_process>closing the write end of the pipe…) \n"); 
        close(pipe_buffer[1]); //line4
        if(debugMod)    fprintf(stderr,"(parent_process>forking…) \n");
        pid2=fork();
         if (pid2==-1)
        {
        perror("failed to create child process");
        exit(1);
     }
        if(!pid2){
            close(STDIN_FILENO);
            if (debugMod)    fprintf(stderr,"(child2>redirecting stdin to the read end of the pipe…)\n");
            if(dup(pipe_buffer[0])==-1){
                perror("failed to duplicate child");
                exit(1);
            }
            close(pipe_buffer[0]);
            if (debugMod)   fprintf(stderr,"(child2>going to execute cmd: …)\n");
            execvp(tailCommand[0],tailCommand);
            exit(1);
        }
        else{
             if (debugMod)   fprintf(stderr,"(parent_process>created process with id: %d\n",pid2);
            if(debugMod)    fprintf(stderr,"(parent_process>closing the read end of the pipe…)\n"); 
            close(pipe_buffer[0]);
            if(debugMod)    fprintf(stderr,"(parent_process>waiting for child processes to terminate…)\n");
            waitpid(pid1,NULL,0);
            waitpid(pid2,NULL,0);
            if(debugMod)    fprintf(stderr,"(parent_process>exiting…)\n");
        }
        return 0;
    }
    


}