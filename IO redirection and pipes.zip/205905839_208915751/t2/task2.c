#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <linux/limits.h>
#include "LineParser.h"
#include <sys/wait.h>
#include <unistd.h>

#define TERMINATED  -1
#define RUNNING 1
#define SUSPENDED 0

int debug=0;


typedef struct process{
    cmdLine* cmd;                         /* the parsed command line*/
    pid_t pid; 		                  /* the process id that is running the command*/
    int status;                           /* status of the process: RUNNING/SUSPENDED/TERMINATED */
    struct process *next;	                  /* next process in chain */
} process;
process **list_process;

void deleteProcess(process *processToDelter);

char* strFromSig(int status)
{
    if (status==RUNNING)
    {
        return "Running";
    }
    if (status==TERMINATED)
    {
        return "Terminated";
    }
    if (status==SUSPENDED)
    {
        return "Suspended";
    }
    return "UNKOWN";
}

void addProcess(process** process_list, cmdLine* cmd, pid_t pid){
    process* new_process=(process*)malloc(sizeof(process));
    new_process->cmd=cmd;
    new_process->status=RUNNING;
    new_process->pid=pid;
    new_process->next=process_list[0];
    process_list[0]=new_process;
}
void updateProcessList(process **process_list)
{
    process* proc=process_list[0];
   
    while (proc!=NULL)
    {
         int wait;
        int adress;
        wait=waitpid(proc->pid,&adress,WNOHANG|WUNTRACED|WCONTINUED);
        if (wait==-1)
        {
            proc->status=TERMINATED;
        }
        else if(wait>0)
        {
            if (WIFSIGNALED(adress)||WIFEXITED(adress))
            {
                proc->status=TERMINATED;
            }
            else if(WIFCONTINUED(adress))
            {
                proc->status=RUNNING;
            }
            else if(WIFSTOPPED(adress))
            {
                proc->status=SUSPENDED;
            }
        }
       
        proc=proc->next;
    }
}
void printProcessList(process** process_list){

    updateProcessList(process_list);
    process*proc=process_list[0];
    printf("PID: \t\tCommand:\t\tSTATUS:\n");
    while (proc!=NULL)
    {
        printf("%d\t\t %s\t\t %s\n",proc->pid,proc->cmd->arguments[0],strFromSig(proc->status));
        process*temp=proc;
        proc=proc->next;
        if (temp->status==TERMINATED)
        {
            deleteProcess(temp);
            
        }

    }
    
}

void freeProcessList(process* process_list)
{
    process* temp = process_list;
    process* isFree = process_list;
    while(temp != NULL){
        temp = temp->next;
        freeCmdLines(isFree->cmd);
        free(isFree);
        isFree = temp; 
    }
   

}

void deleteProcess(process *processToDelter)
{
    process * list=list_process[0];
    if (list==processToDelter)
    {
        list_process[0]=list->next;
        freeCmdLines(processToDelter->cmd);
        free(processToDelter);
        
    }
    else {
        while (list->next!=NULL)
        {
            if (list->next==processToDelter)
            {
                list->next=processToDelter->next;
                freeCmdLines(processToDelter->cmd);
                free(processToDelter);
                break;
            }
            list=list->next;
        }
    }

}

void execute(cmdLine *cmd){
    if (strcmp(cmd->arguments[0],"suspend")==0)
        {
            int pid;
            if(!(pid=fork())){
                if(debug==1){
                    fprintf(stderr,"%d\n",pid);
                }
                kill(atoi(cmd->arguments[1]),SIGTSTP);
                sleep(atoi(cmd->arguments[2]));
                kill(atoi(cmd->arguments[1]),SIGCONT);
                freeCmdLines(cmd);
                freeProcessList(list_process[0]);
                exit(0);
                
            }
        }
        else if (strcmp(cmd->arguments[0],"kill")==0)
        {
            kill(atoi(cmd->arguments[1]),SIGCONT);
            kill(atoi(cmd->arguments[1]),SIGINT);
            freeCmdLines(cmd);
                
            
        }
        else if (strcmp(cmd->arguments[0],"procs")==0)
        {

            printProcessList(list_process);
            freeCmdLines(cmd);
            
        }
       else{
        pid_t pid1,pid2;
        int piper[2];
        if(cmd->next!=NULL){
            if(pipe(piper)==-1){
                perror("failed to open pipe\n");
                exit(1);
            }
            pid1=fork();
            if(!pid1){
                close(STDOUT_FILENO);
                dup(piper[1]);
                close(piper[1]);
                if(cmd->inputRedirect!=NULL){
                    close(STDIN_FILENO);
                    fopen(cmd->inputRedirect,"r");
                } 
                execvp(cmd->arguments[0],cmd->arguments);
            }
            close(piper[1]);
            pid2=fork();
            if(!pid2){
                close(STDIN_FILENO);
                dup(piper[0]);
                close(piper[0]);
                if(cmd->outputRedirect!=NULL){ //task0b
                    close(STDOUT_FILENO);
                    fopen(cmd->outputRedirect,"a+");
                    }
                    execvp(cmd->next->arguments[0],cmd->next->arguments);
            }
            close(piper[0]);
            freeCmdLines(cmd);
            waitpid(pid1,NULL,0);
            waitpid(pid2,NULL,0);   
            }
            else{
                pid1=fork();
                if(!pid1){
                    if(pipe(piper)==-1){
                    perror("failed to open pipe\n");
                    exit(1);
                    }
                    if(cmd->inputRedirect!=NULL){
                        close(STDIN_FILENO);
                        fopen(cmd->inputRedirect,"r");
                    }
                    if(cmd->outputRedirect!=NULL){ //task0b
                        close(STDOUT_FILENO);
                        fopen(cmd->outputRedirect,"w+");
                    }
                    execvp(cmd->arguments[0],cmd->arguments);
                    perror("Execvp error");
                    exit(1);
                }
                else{
                    addProcess(list_process,cmd,pid1);
                }
                int status; 
            if (cmd->blocking==1)
            {
                waitpid(pid1, &status, 0);
            }
            }
        }
}



void updateProcessStatus(process* process_list, int pid, int status)
{
    while (process_list!=NULL)
    {
        if (process_list->pid==pid)
        {
            process_list->status=status;
            break;
        }
        process_list=process_list->next;
    }
}



int main(int argc,char**argv)
{
    process* pro =NULL;
    list_process=&pro;
    
    int j;
    int cd;
    char input[2048];
    char curr_directory[PATH_MAX];
    for (j = 1; j < argc; j++) {
        if ((argv[j][0] == '-') & (argv[j][1] == 'd')){
                debug = 1;
        }
        
    }
    

    while (1)
    {
        getcwd(curr_directory,PATH_MAX);
        printf("%s\n",curr_directory);
        fgets(input,2048,stdin);
        cmdLine* cmd=parseCmdLines(input);
        if (strcmp(cmd->arguments[0],"quit")==0)
        {
            printf("normally quitting\n");
            freeCmdLines(cmd);
            freeProcessList(list_process[0]);
            exit(0);
        }
        else if (strcmp(cmd->arguments[0],"cd")==0)
        {
            printf("please enter a new path\n");
            fgets(curr_directory,2048,stdin);
            cd=chdir(curr_directory);
            if (cd==-1&&debug==1){
                perror("error ");
            }
            freeCmdLines(cmd);
        }
        else 
        execute(cmd);

       

    }
    return 0;
}

